package t ;


public class no_const {
	public int i = 5 ;
}

