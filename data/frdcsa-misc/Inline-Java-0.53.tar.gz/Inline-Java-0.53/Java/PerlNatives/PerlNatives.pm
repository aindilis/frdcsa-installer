package Inline::Java::PerlNatives ;

use strict ;

$Inline::Java::PerlNatives::VERSION = '0.52' ;

1 ;
