class t10 {
	static public int i = 5 ;

	public t10(){
	}

	static synchronized public void incr(){
		i++ ;
	}
}

