package t ;

import java.util.* ;


public class types {
	public types(){
	}

	public String func(){
		return "study" ;
	}

	public HashMap hm(){
		HashMap hm = new HashMap() ;
		hm.put("key", "value") ;

		return hm ;
	}
}
