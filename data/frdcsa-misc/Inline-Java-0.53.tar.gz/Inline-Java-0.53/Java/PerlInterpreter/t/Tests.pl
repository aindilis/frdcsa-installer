package main ;
use strict ;

sub whats_your_name {
	return "perl" ;
}

1 ;
